public class Main {

    public static void main(String[] args) {
        Lessons3_TimeComplexity_3_TapeEquilibrium suit = new Lessons3_TimeComplexity_3_TapeEquilibrium();

        System.out.println(suit.solution1());
    }
}
