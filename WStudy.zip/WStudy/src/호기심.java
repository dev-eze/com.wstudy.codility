public class 호기심 {


    int max = Integer.MAX_VALUE; // 2,147,483,647
    int maxOverFlow = max + 1; // -2,147,483,648 로 변경됨

    int min = Integer.MAX_VALUE; // -2,147,483,648
    int minOverFlow = min - 1; // 2,147,483,647 로 변경됨.
}
